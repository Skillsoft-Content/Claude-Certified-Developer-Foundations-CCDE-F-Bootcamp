"""
AI Resume Screener - Senior Recruiter Assistant
------------------------------------------------
Upload multiple resumes (PDF / DOCX), paste a Job Description, and let OpenAI
score each profile. Candidates at or above the threshold (default 85%) are
marked SELECTED, the rest NOT SELECTED, with detailed reasoning per candidate.

Features
  * Browse & upload multiple PDF / DOCX profiles
  * OpenAI API key entered at runtime (never stored on disk)
  * Summary tab with match % and status
  * Selected / Not Selected tabs with detailed explanations
  * Download (copy) profiles to a folder, export report to CSV
  * Send email directly to candidates (SMTP, e.g. Gmail app password)

Install:  pip install -r requirements.txt
Run:      python resume_screener_app.py
"""

import csv
import json
import os
import re
import shutil
import smtplib
import ssl
import threading
import tkinter as tk
from email.message import EmailMessage
from tkinter import filedialog, messagebox, scrolledtext, ttk

# ---------------------------------------------------------------- theme ----
BG = "#EAF4FF"          # light blue background
PANEL = "#F7FBFF"       # panel background
ACCENT = "#1E88E5"      # primary blue
ACCENT_DARK = "#1565C0"
TEXT = "#0D2B45"
GREEN = "#2E7D32"
RED = "#C62828"
FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI", 16, "bold")

DEFAULT_MODEL = "gpt-4o-mini"
MAX_RESUME_CHARS = 15000


# ------------------------------------------------------- text extraction ----
def extract_text(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".pdf":
        try:
            from pypdf import PdfReader
        except ImportError:
            raise RuntimeError("pypdf not installed. Run: pip install pypdf")
        reader = PdfReader(path)
        return "\n".join((page.extract_text() or "") for page in reader.pages)
    if ext == ".docx":
        try:
            import docx
        except ImportError:
            raise RuntimeError("python-docx not installed. Run: pip install python-docx")
        document = docx.Document(path)
        parts = [p.text for p in document.paragraphs]
        for table in document.tables:
            for row in table.rows:
                parts.append(" | ".join(cell.text for cell in row.cells))
        return "\n".join(parts)
    raise RuntimeError(f"Unsupported file type '{ext}'. Use PDF or DOCX (save .doc as .docx).")


def find_email(text):
    match = re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", text)
    return match.group(0) if match else ""


# ------------------------------------------------------------ AI scoring ----
SYSTEM_PROMPT = """You are a Senior Technical Recruiter with 15+ years of experience.
Evaluate the candidate resume strictly against the job description.
Be objective: weigh must-have skills, years/relevance of experience, domain,
education/certifications, and role seniority. Do not inflate scores.
Respond ONLY with valid JSON using exactly these keys:
{
  "candidate_name": string,
  "email": string,
  "phone": string,
  "total_experience": string,
  "match_percentage": integer 0-100,
  "matched_skills": [string],
  "missing_skills": [string],
  "strengths": [string],
  "concerns": [string],
  "experience_fit": string,
  "summary": string (2-3 sentences),
  "decision_reason": string (why this candidate should / should not move forward)
}"""


def analyze_resume(client, model, jd, resume_text):
    user_msg = (
        f"JOB DESCRIPTION:\n{jd}\n\n"
        f"CANDIDATE RESUME:\n{resume_text[:MAX_RESUME_CHARS]}"
    )
    response = client.chat.completions.create(
        model=model,
        temperature=0.2,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_msg},
        ],
    )
    return json.loads(response.choices[0].message.content)


# ------------------------------------------------------------------ app ----
class ResumeScreenerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("AI Resume Screener - Senior Recruiter Assistant")
        self.geometry("1150x760")
        self.minsize(950, 650)
        self.configure(bg=BG)

        self.files = []        # uploaded file paths
        self.results = []      # analysis results (list of dicts)
        self.smtp = {"server": "smtp.gmail.com", "port": "587", "sender": "", "password": ""}

        self._style()
        self._build_header()
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self._build_setup_tab()
        self._build_summary_tab()
        self.sel_tab = self._build_detail_tab("✅ Selected", "Selected")
        self.rej_tab = self._build_detail_tab("❌ Not Selected", "Not Selected")

    # ------------------------------------------------------------ styling --
    def _style(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure(".", background=BG, foreground=TEXT, font=FONT)
        s.configure("TFrame", background=BG)
        s.configure("Panel.TFrame", background=PANEL)
        s.configure("TLabel", background=BG, foreground=TEXT)
        s.configure("Panel.TLabel", background=PANEL)
        s.configure("TLabelframe", background=PANEL, bordercolor="#BBDEFB")
        s.configure("TLabelframe.Label", background=PANEL, foreground=ACCENT_DARK, font=FONT_BOLD)
        s.configure("TNotebook", background=BG, borderwidth=0)
        s.configure("TNotebook.Tab", background="#D6EAFE", foreground=TEXT,
                    padding=(16, 7), font=FONT_BOLD)
        s.map("TNotebook.Tab", background=[("selected", ACCENT)],
              foreground=[("selected", "white")])
        s.configure("Accent.TButton", background=ACCENT, foreground="white",
                    font=FONT_BOLD, padding=(12, 6), borderwidth=0)
        s.map("Accent.TButton", background=[("active", ACCENT_DARK), ("disabled", "#90CAF9")])
        s.configure("TButton", background="#D6EAFE", foreground=TEXT, padding=(10, 5), borderwidth=0)
        s.map("TButton", background=[("active", "#BBDEFB")])
        s.configure("Treeview", background="white", fieldbackground="white",
                    rowheight=28, font=FONT)
        s.configure("Treeview.Heading", background=ACCENT, foreground="white", font=FONT_BOLD)
        s.map("Treeview.Heading", background=[("active", ACCENT_DARK)])
        s.map("Treeview", background=[("selected", "#90CAF9")], foreground=[("selected", TEXT)])
        s.configure("Horizontal.TProgressbar", background=ACCENT, troughcolor="#D6EAFE")

    def _build_header(self):
        bar = tk.Frame(self, bg=ACCENT, height=56)
        bar.pack(fill="x", pady=(0, 10))
        tk.Label(bar, text="🧑‍💼  AI Resume Screener", bg=ACCENT, fg="white",
                 font=FONT_TITLE).pack(side="left", padx=16, pady=10)
        tk.Label(bar, text="Upload profiles • Match with JD • Shortlist • Email",
                 bg=ACCENT, fg="#E3F2FD", font=FONT).pack(side="right", padx=16)

    # --------------------------------------------------------- setup tab --
    def _build_setup_tab(self):
        tab = ttk.Frame(self.nb, padding=10)
        self.nb.add(tab, text="⚙  Upload & Analyze")

        # API settings
        api = ttk.LabelFrame(tab, text="OpenAI Settings", padding=10)
        api.pack(fill="x")
        ttk.Label(api, text="API Key:", style="Panel.TLabel").grid(row=0, column=0, sticky="w")
        self.api_var = tk.StringVar()
        self.api_entry = ttk.Entry(api, textvariable=self.api_var, show="•", width=55)
        self.api_entry.grid(row=0, column=1, padx=6, sticky="we")
        self.show_key = tk.BooleanVar()
        tk.Checkbutton(api, text="Show", variable=self.show_key, bg=PANEL,
                       command=lambda: self.api_entry.config(show="" if self.show_key.get() else "•")
                       ).grid(row=0, column=2)
        ttk.Label(api, text="Model:", style="Panel.TLabel").grid(row=0, column=3, padx=(16, 4))
        self.model_var = tk.StringVar(value=DEFAULT_MODEL)
        ttk.Combobox(api, textvariable=self.model_var, width=16,
                     values=["gpt-4o-mini", "gpt-4o", "gpt-4.1-mini", "gpt-4.1"]
                     ).grid(row=0, column=4)
        ttk.Label(api, text="Threshold %:", style="Panel.TLabel").grid(row=0, column=5, padx=(16, 4))
        self.threshold_var = tk.IntVar(value=85)
        ttk.Spinbox(api, from_=1, to=100, textvariable=self.threshold_var, width=5).grid(row=0, column=6)
        api.columnconfigure(1, weight=1)

        body = ttk.Frame(tab)
        body.pack(fill="both", expand=True, pady=10)
        body.columnconfigure(0, weight=1)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)

        # Box 1: resumes
        box1 = ttk.LabelFrame(body, text="1. Candidate Profiles (PDF / DOCX)", padding=10)
        box1.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        btns = ttk.Frame(box1, style="Panel.TFrame")
        btns.pack(fill="x")
        ttk.Button(btns, text="📂 Browse...", style="Accent.TButton",
                   command=self.browse_files).pack(side="left")
        ttk.Button(btns, text="Remove", command=self.remove_file).pack(side="left", padx=6)
        ttk.Button(btns, text="Clear All", command=self.clear_files).pack(side="left")
        self.count_lbl = ttk.Label(btns, text="0 files", style="Panel.TLabel")
        self.count_lbl.pack(side="right")
        self.file_list = tk.Listbox(box1, selectmode="extended", bg="white", fg=TEXT,
                                    font=FONT, relief="flat", highlightthickness=1,
                                    highlightcolor=ACCENT, highlightbackground="#BBDEFB",
                                    selectbackground="#90CAF9")
        self.file_list.pack(fill="both", expand=True, pady=(8, 0))

        # Box 2: JD
        box2 = ttk.LabelFrame(body, text="2. Job Description", padding=10)
        box2.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        jd_btns = ttk.Frame(box2, style="Panel.TFrame")
        jd_btns.pack(fill="x")
        ttk.Button(jd_btns, text="Load JD from file", command=self.load_jd).pack(side="left")
        ttk.Button(jd_btns, text="Clear", command=lambda: self.jd_text.delete("1.0", "end")
                   ).pack(side="left", padx=6)
        self.jd_text = scrolledtext.ScrolledText(box2, wrap="word", font=FONT, bg="white",
                                                 fg=TEXT, relief="flat", highlightthickness=1,
                                                 highlightcolor=ACCENT,
                                                 highlightbackground="#BBDEFB")
        self.jd_text.pack(fill="both", expand=True, pady=(8, 0))

        # Analyze row
        run = ttk.Frame(tab)
        run.pack(fill="x")
        self.analyze_btn = ttk.Button(run, text="🔍  Analyze Profiles", style="Accent.TButton",
                                      command=self.start_analysis)
        self.analyze_btn.pack(side="left")
        self.progress = ttk.Progressbar(run, mode="determinate", length=320)
        self.progress.pack(side="left", padx=12)
        self.status_lbl = ttk.Label(run, text="Ready")
        self.status_lbl.pack(side="left")

    # ------------------------------------------------------- summary tab --
    def _build_summary_tab(self):
        tab = ttk.Frame(self.nb, padding=10)
        self.nb.add(tab, text="📊  Summary")

        self.stats_lbl = ttk.Label(tab, text="No analysis yet.", font=FONT_BOLD)
        self.stats_lbl.pack(anchor="w", pady=(0, 8))

        cols = ("name", "email", "exp", "score", "status", "file")
        heads = ("Candidate", "Email", "Experience", "Match %", "Status", "File")
        widths = (180, 220, 100, 80, 120, 260)
        frame = ttk.Frame(tab)
        frame.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(frame, columns=cols, show="headings", selectmode="extended")
        for c, h, w in zip(cols, heads, widths):
            self.tree.heading(c, text=h, command=lambda c=c: self.sort_tree(c))
            self.tree.column(c, width=w, anchor="center" if c in ("score", "status", "exp") else "w")
        self.tree.tag_configure("sel", foreground=GREEN, background="#EDF7EE")
        self.tree.tag_configure("rej", foreground=RED, background="#FDEEEE")
        vsb = ttk.Scrollbar(frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        self.tree.bind("<Double-1>", lambda e: self.open_from_summary())

        btns = ttk.Frame(tab)
        btns.pack(fill="x", pady=(10, 0))
        ttk.Button(btns, text="⬇ Download Highlighted", style="Accent.TButton",
                   command=lambda: self.download_profiles(self.summary_selection())).pack(side="left")
        ttk.Button(btns, text="⬇ Download All Selected",
                   command=lambda: self.download_profiles(self.by_status("Selected"))
                   ).pack(side="left", padx=6)
        ttk.Button(btns, text="📄 Export Report (CSV)", command=self.export_csv).pack(side="left")
        ttk.Button(btns, text="✉ Email Highlighted", style="Accent.TButton",
                   command=lambda: self.email_candidates(self.summary_selection())
                   ).pack(side="right")
        ttk.Label(tab, text="Tip: double-click a row to view the detailed explanation.",
                  foreground="#5B7A99").pack(anchor="w", pady=(6, 0))

    # ------------------------------------------ selected / rejected tabs --
    def _build_detail_tab(self, title, status):
        tab = ttk.Frame(self.nb, padding=10)
        self.nb.add(tab, text=title)
        paned = ttk.PanedWindow(tab, orient="horizontal")
        paned.pack(fill="both", expand=True)

        left = ttk.LabelFrame(paned, text=f"{status} Candidates", padding=8)
        lb = tk.Listbox(left, bg="white", fg=GREEN if status == "Selected" else RED,
                        font=FONT_BOLD, relief="flat", highlightthickness=1,
                        highlightbackground="#BBDEFB", selectbackground="#90CAF9",
                        exportselection=False, width=32)
        lb.pack(fill="both", expand=True)
        paned.add(left, weight=1)

        right = ttk.LabelFrame(paned, text="Detailed Explanation", padding=8)
        txt = scrolledtext.ScrolledText(right, wrap="word", font=FONT, bg="white", fg=TEXT,
                                        relief="flat", padx=10, pady=8)
        txt.pack(fill="both", expand=True)
        txt.tag_configure("h1", font=("Segoe UI", 14, "bold"), foreground=ACCENT_DARK)
        txt.tag_configure("h2", font=FONT_BOLD, foreground=ACCENT_DARK, spacing1=8)
        txt.tag_configure("good", foreground=GREEN, font=FONT_BOLD)
        txt.tag_configure("bad", foreground=RED, font=FONT_BOLD)
        paned.add(right, weight=3)

        btns = ttk.Frame(tab)
        btns.pack(fill="x", pady=(10, 0))
        ui = {"status": status, "list": lb, "text": txt, "items": []}

        def current():
            idx = lb.curselection()
            return [ui["items"][i] for i in idx]

        ttk.Button(btns, text="⬇ Download Profile", style="Accent.TButton",
                   command=lambda: self.download_profiles(current())).pack(side="left")
        ttk.Button(btns, text=f"⬇ Download All {status}",
                   command=lambda: self.download_profiles(ui["items"])).pack(side="left", padx=6)
        ttk.Button(btns, text="✉ Send Email", style="Accent.TButton",
                   command=lambda: self.email_candidates(current())).pack(side="right")
        ttk.Button(btns, text=f"✉ Email All {status}",
                   command=lambda: self.email_candidates(ui["items"])).pack(side="right", padx=6)

        lb.bind("<<ListboxSelect>>", lambda e: self.show_detail(ui))
        return ui

    # ----------------------------------------------------- file handling --
    def browse_files(self):
        paths = filedialog.askopenfilenames(
            title="Select candidate profiles",
            filetypes=[("Resumes", "*.pdf *.docx"), ("PDF", "*.pdf"), ("Word", "*.docx")])
        for p in paths:
            if p not in self.files:
                self.files.append(p)
                self.file_list.insert("end", os.path.basename(p))
        self.count_lbl.config(text=f"{len(self.files)} files")

    def remove_file(self):
        for i in reversed(self.file_list.curselection()):
            self.file_list.delete(i)
            self.files.pop(i)
        self.count_lbl.config(text=f"{len(self.files)} files")

    def clear_files(self):
        self.files.clear()
        self.file_list.delete(0, "end")
        self.count_lbl.config(text="0 files")

    def load_jd(self):
        path = filedialog.askopenfilename(filetypes=[("JD", "*.txt *.pdf *.docx")])
        if not path:
            return
        try:
            if path.lower().endswith(".txt"):
                with open(path, encoding="utf-8", errors="ignore") as f:
                    text = f.read()
            else:
                text = extract_text(path)
            self.jd_text.delete("1.0", "end")
            self.jd_text.insert("1.0", text)
        except Exception as e:
            messagebox.showerror("Error", f"Could not read JD:\n{e}")

    # ---------------------------------------------------------- analysis --
    def start_analysis(self):
        key = self.api_var.get().strip()
        jd = self.jd_text.get("1.0", "end").strip()
        if not key:
            return messagebox.showwarning("Missing", "Please enter your OpenAI API key.")
        if not self.files:
            return messagebox.showwarning("Missing", "Please upload at least one profile.")
        if len(jd) < 30:
            return messagebox.showwarning("Missing", "Please provide a proper Job Description.")
        try:
            threshold = int(self.threshold_var.get())
        except (tk.TclError, ValueError):
            return messagebox.showwarning("Invalid", "Threshold must be a number (1-100).")
        try:
            from openai import OpenAI
        except ImportError:
            return messagebox.showerror("Missing", "openai not installed. Run: pip install openai")

        client = OpenAI(api_key=key)
        self.analyze_btn.config(state="disabled")
        self.progress.config(maximum=len(self.files), value=0)
        threading.Thread(target=self._run_analysis,
                         args=(client, self.model_var.get().strip() or DEFAULT_MODEL,
                               jd, list(self.files), threshold),
                         daemon=True).start()

    def _run_analysis(self, client, model, jd, files, threshold):
        results = []
        for i, path in enumerate(files, 1):
            name = os.path.basename(path)
            self.after(0, self.status_lbl.config, {"text": f"Analyzing {i}/{len(files)}: {name}"})
            try:
                text = extract_text(path)
                if not text.strip():
                    raise RuntimeError("No readable text (scanned image PDF?)")
                data = analyze_resume(client, model, jd, text)
                score = max(0, min(100, int(float(data.get("match_percentage", 0)))))
                data["match_percentage"] = score
                data["email"] = data.get("email") or find_email(text)
                data["candidate_name"] = data.get("candidate_name") or os.path.splitext(name)[0]
                data["status"] = "Selected" if score >= threshold else "Not Selected"
            except Exception as e:
                data = {"candidate_name": os.path.splitext(name)[0], "email": "",
                        "match_percentage": 0, "status": "Not Selected",
                        "summary": "Analysis failed.", "decision_reason": f"Error: {e}",
                        "error": True}
                if "api key" in str(e).lower() or "401" in str(e):
                    self.after(0, messagebox.showerror, "OpenAI Error", f"Authentication failed:\n{e}")
            data["file"] = path
            data["threshold"] = threshold
            results.append(data)
            self.after(0, self.progress.config, {"value": i})
        self.after(0, self._analysis_done, results)

    def _analysis_done(self, results):
        self.results = sorted(results, key=lambda r: r["match_percentage"], reverse=True)
        self.analyze_btn.config(state="normal")
        sel = self.by_status("Selected")
        self.status_lbl.config(text=f"Done: {len(sel)} selected / {len(self.results)} profiles")
        self.refresh_views()
        self.nb.select(1)

    # ------------------------------------------------------------- views --
    def refresh_views(self):
        self.tree.delete(*self.tree.get_children())
        for idx, r in enumerate(self.results):
            tag = "sel" if r["status"] == "Selected" else "rej"
            icon = "✅ Selected" if tag == "sel" else "❌ Not Selected"
            self.tree.insert("", "end", iid=str(idx), tags=(tag,), values=(
                r.get("candidate_name", ""), r.get("email", ""), r.get("total_experience", "-"),
                f'{r["match_percentage"]}%', icon, os.path.basename(r["file"])))
        n_sel = len(self.by_status("Selected"))
        total = len(self.results)
        avg = sum(r["match_percentage"] for r in self.results) / total if total else 0
        thr = self.results[0]["threshold"] if self.results else self.threshold_var.get()
        self.stats_lbl.config(
            text=f"Total: {total}   |   ✅ Selected: {n_sel}   |   ❌ Not Selected: {total - n_sel}"
                 f"   |   Avg Match: {avg:.1f}%   |   Threshold: {thr}%")

        for ui in (self.sel_tab, self.rej_tab):
            ui["items"] = self.by_status(ui["status"])
            ui["list"].delete(0, "end")
            for r in ui["items"]:
                ui["list"].insert("end", f'{r["match_percentage"]:>3}%  {r["candidate_name"]}')
            ui["text"].delete("1.0", "end")
            if ui["items"]:
                ui["list"].selection_set(0)
                self.show_detail(ui)
            else:
                ui["text"].insert("end", f"No {ui['status'].lower()} candidates.")

    def show_detail(self, ui):
        idx = ui["list"].curselection()
        if not idx:
            return
        r = ui["items"][idx[0]]
        t = ui["text"]
        t.delete("1.0", "end")
        selected = r["status"] == "Selected"

        t.insert("end", f'{r["candidate_name"]}\n', "h1")
        t.insert("end", f'Match Score: {r["match_percentage"]}%   (threshold {r["threshold"]}%)\n',
                 "good" if selected else "bad")
        t.insert("end", f'Decision: {"SELECTED ✅" if selected else "NOT SELECTED ❌"}\n',
                 "good" if selected else "bad")
        t.insert("end", f'Email: {r.get("email") or "-"}    Phone: {r.get("phone") or "-"}\n')
        t.insert("end", f'Experience: {r.get("total_experience") or "-"}\n')
        t.insert("end", f'File: {r["file"]}\n')

        t.insert("end", "\nSummary\n", "h2")
        t.insert("end", f'{r.get("summary", "")}\n')
        t.insert("end", "\nWhy " + ("Selected" if selected else "Not Selected") + "\n", "h2")
        t.insert("end", f'{r.get("decision_reason", "")}\n')
        if r.get("experience_fit"):
            t.insert("end", "\nExperience Fit\n", "h2")
            t.insert("end", f'{r["experience_fit"]}\n')

        def bullets(title, items, tag=None):
            if items:
                t.insert("end", f"\n{title}\n", "h2")
                for it in items:
                    t.insert("end", f"  • {it}\n", tag or ())

        bullets("Matched Skills", r.get("matched_skills"), "good")
        bullets("Missing Skills / Gaps", r.get("missing_skills"), "bad")
        bullets("Strengths", r.get("strengths"))
        bullets("Concerns", r.get("concerns"))

    def open_from_summary(self):
        chosen = self.summary_selection()
        if not chosen:
            return
        r = chosen[0]
        ui = self.sel_tab if r["status"] == "Selected" else self.rej_tab
        self.nb.select(2 if ui is self.sel_tab else 3)
        i = ui["items"].index(r)
        ui["list"].selection_clear(0, "end")
        ui["list"].selection_set(i)
        ui["list"].see(i)
        self.show_detail(ui)

    def sort_tree(self, col):
        key = {"score": lambda r: r["match_percentage"],
               "name": lambda r: r.get("candidate_name", "").lower(),
               "status": lambda r: r["status"],
               "email": lambda r: r.get("email", ""),
               "exp": lambda r: str(r.get("total_experience", "")),
               "file": lambda r: os.path.basename(r["file"])}[col]
        reverse = getattr(self, "_sort_rev", False)
        self.results.sort(key=key, reverse=reverse)
        self._sort_rev = not reverse
        self.refresh_views()

    # ----------------------------------------------------------- helpers --
    def by_status(self, status):
        return [r for r in self.results if r["status"] == status]

    def summary_selection(self):
        return [self.results[int(i)] for i in self.tree.selection()]

    # ---------------------------------------------------- download/export --
    def download_profiles(self, items):
        if not items:
            return messagebox.showinfo("Download", "No profiles chosen.")
        folder = filedialog.askdirectory(title="Choose folder to save profiles")
        if not folder:
            return
        copied = 0
        for r in items:
            try:
                shutil.copy2(r["file"], os.path.join(folder, os.path.basename(r["file"])))
                copied += 1
            except Exception as e:
                messagebox.showerror("Error", f"Could not copy {r['file']}:\n{e}")
        messagebox.showinfo("Download", f"{copied} profile(s) saved to:\n{folder}")

    def export_csv(self):
        if not self.results:
            return messagebox.showinfo("Export", "Run an analysis first.")
        path = filedialog.asksaveasfilename(defaultextension=".csv",
                                            initialfile="screening_report.csv",
                                            filetypes=[("CSV", "*.csv")])
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["Candidate", "Email", "Phone", "Experience", "Match %", "Status",
                        "Matched Skills", "Missing Skills", "Summary", "Reason", "File"])
            for r in self.results:
                w.writerow([r.get("candidate_name"), r.get("email"), r.get("phone"),
                            r.get("total_experience"), r["match_percentage"], r["status"],
                            "; ".join(r.get("matched_skills") or []),
                            "; ".join(r.get("missing_skills") or []),
                            r.get("summary"), r.get("decision_reason"), r["file"]])
        messagebox.showinfo("Export", f"Report saved:\n{path}")

    # ------------------------------------------------------------- email --
    def email_candidates(self, items):
        if not items:
            return messagebox.showinfo("Email", "No candidates chosen.")
        EmailDialog(self, items)


class EmailDialog(tk.Toplevel):
    SELECTED_TMPL = (
        "Dear {name},\n\n"
        "Thank you for your interest in the position. We are pleased to inform you that "
        "your profile has been shortlisted for the next round of our hiring process.\n\n"
        "Our team will reach out shortly to schedule the interview. Please reply with your "
        "availability for the coming week.\n\n"
        "Best regards,\nTalent Acquisition Team")
    REJECTED_TMPL = (
        "Dear {name},\n\n"
        "Thank you for taking the time to apply. After careful review, we have decided to "
        "move forward with candidates whose experience more closely matches the current "
        "requirements.\n\n"
        "We will keep your profile on file and reach out if a suitable opportunity arises. "
        "We wish you every success in your job search.\n\n"
        "Best regards,\nTalent Acquisition Team")

    def __init__(self, app, items):
        super().__init__(app)
        self.app = app
        self.items = items
        self.title("Send Email")
        self.configure(bg=BG)
        self.geometry("640x640")
        self.transient(app)
        self.grab_set()

        smtp = ttk.LabelFrame(self, text="SMTP Settings (Gmail: use an App Password)", padding=10)
        smtp.pack(fill="x", padx=12, pady=10)
        self.vars = {k: tk.StringVar(value=v) for k, v in app.smtp.items()}
        fields = [("SMTP Server", "server", ""), ("Port", "port", ""),
                  ("Your Email", "sender", ""), ("App Password", "password", "•")]
        for i, (lbl, key, show) in enumerate(fields):
            ttk.Label(smtp, text=lbl, style="Panel.TLabel").grid(row=i // 2, column=(i % 2) * 2,
                                                                sticky="w", pady=3)
            ttk.Entry(smtp, textvariable=self.vars[key], show=show, width=28
                      ).grid(row=i // 2, column=(i % 2) * 2 + 1, padx=6, pady=3)

        msg = ttk.LabelFrame(self, text="Message", padding=10)
        msg.pack(fill="both", expand=True, padx=12)
        first = items[0]
        selected = first["status"] == "Selected"
        recipients = ", ".join(r.get("email") or f"<missing: {r['candidate_name']}>" for r in items)
        ttk.Label(msg, text="To:", style="Panel.TLabel").grid(row=0, column=0, sticky="w")
        self.to_var = tk.StringVar(value=recipients)
        ttk.Entry(msg, textvariable=self.to_var, width=62).grid(row=0, column=1, sticky="we", pady=3)
        ttk.Label(msg, text="Subject:", style="Panel.TLabel").grid(row=1, column=0, sticky="w")
        self.subj_var = tk.StringVar(
            value="Congratulations - You've Been Shortlisted" if selected
            else "Update on Your Application")
        ttk.Entry(msg, textvariable=self.subj_var, width=62).grid(row=1, column=1, sticky="we", pady=3)
        ttk.Label(msg, text="Body ({name} is auto-filled per candidate):",
                  style="Panel.TLabel").grid(row=2, column=0, columnspan=2, sticky="w", pady=(6, 2))
        self.body = scrolledtext.ScrolledText(msg, wrap="word", font=FONT, height=12, bg="white")
        self.body.grid(row=3, column=0, columnspan=2, sticky="nsew")
        self.body.insert("1.0", self.SELECTED_TMPL if selected else self.REJECTED_TMPL)
        self.attach = tk.BooleanVar(value=False)
        tk.Checkbutton(msg, text="Attach candidate's resume", variable=self.attach, bg=PANEL
                       ).grid(row=4, column=0, columnspan=2, sticky="w", pady=4)
        msg.columnconfigure(1, weight=1)
        msg.rowconfigure(3, weight=1)
        ttk.Label(msg, text="Note: with multiple candidates, each receives an individual email.",
                  style="Panel.TLabel", foreground="#5B7A99").grid(row=5, column=0, columnspan=2,
                                                                  sticky="w")

        bar = ttk.Frame(self)
        bar.pack(fill="x", padx=12, pady=10)
        self.status = ttk.Label(bar, text="")
        self.status.pack(side="left")
        ttk.Button(bar, text="Cancel", command=self.destroy).pack(side="right")
        self.send_btn = ttk.Button(bar, text="✉ Send", style="Accent.TButton", command=self.send)
        self.send_btn.pack(side="right", padx=6)

    def send(self):
        cfg = {k: v.get().strip() for k, v in self.vars.items()}
        if not cfg["sender"] or not cfg["password"]:
            return messagebox.showwarning("SMTP", "Enter your email and app password.", parent=self)
        addresses = [a.strip() for a in self.to_var.get().split(",")]
        if len(addresses) != len(self.items) or any(
                not re.fullmatch(r"[\w.+-]+@[\w-]+\.[\w.-]+", a) for a in addresses):
            return messagebox.showwarning(
                "Recipients", "Provide one valid email per candidate (comma-separated, same order).",
                parent=self)
        self.app.smtp.update(cfg)  # remember for this session only
        jobs = list(zip(self.items, addresses))
        self.send_btn.config(state="disabled")
        threading.Thread(target=self._send_all, daemon=True,
                         args=(cfg, jobs, self.subj_var.get(), self.body.get("1.0", "end"),
                               self.attach.get())).start()

    def _send_all(self, cfg, jobs, subject, body, attach):
        sent, errors = 0, []
        try:
            with smtplib.SMTP(cfg["server"], int(cfg["port"]), timeout=30) as server:
                server.starttls(context=ssl.create_default_context())
                server.login(cfg["sender"], cfg["password"])
                for r, addr in jobs:
                    try:
                        m = EmailMessage()
                        m["From"], m["To"], m["Subject"] = cfg["sender"], addr, subject
                        m.set_content(body.replace("{name}", r.get("candidate_name", "Candidate")))
                        if attach:
                            with open(r["file"], "rb") as f:
                                ext = os.path.splitext(r["file"])[1].lower()
                                sub = "pdf" if ext == ".pdf" else \
                                    "vnd.openxmlformats-officedocument.wordprocessingml.document"
                                m.add_attachment(f.read(), maintype="application", subtype=sub,
                                                 filename=os.path.basename(r["file"]))
                        server.send_message(m)
                        sent += 1
                    except Exception as e:
                        errors.append(f"{addr}: {e}")
        except Exception as e:
            errors.append(f"SMTP connection/login failed: {e}")
        self.after(0, self._done, sent, errors)

    def _done(self, sent, errors):
        self.send_btn.config(state="normal")
        if errors:
            messagebox.showerror("Email", f"Sent: {sent}\nErrors:\n" + "\n".join(errors), parent=self)
        else:
            messagebox.showinfo("Email", f"{sent} email(s) sent successfully.", parent=self)
            self.destroy()


if __name__ == "__main__":
    ResumeScreenerApp().mainloop()
