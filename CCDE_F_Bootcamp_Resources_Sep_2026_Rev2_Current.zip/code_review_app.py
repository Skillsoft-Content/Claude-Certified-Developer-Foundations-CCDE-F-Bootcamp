"""
AI Code Review Studio - Senior Code Reviewer Assistant
------------------------------------------------------
Browse code files (any programming language) or paste code, then run 10
different AI-powered review checks. Each check gets its own score, findings
(with severity, line numbers and fixes) and recommendations.

The 10 checks
  1. Best Practices            6. Readability & Style
  2. Secure Coding (OWASP)     7. Maintainability & Complexity
  3. Bugs & Logic Errors       8. Documentation & Comments
  4. Performance & Efficiency  9. Testability & Test Coverage
  5. Error Handling           10. Design & SOLID Principles

Extras: dashboard with overall score/grade, export HTML/JSON report,
AI-generated improved code (copy / save).

Install:  pip install openai
Run:      python code_review_app.py
"""

import html
import json
import os
import threading
import tkinter as tk
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from tkinter import filedialog, messagebox, scrolledtext, ttk

# ---------------------------------------------------------------- theme ----
BG = "#EAF4FF"
PANEL = "#F7FBFF"
ACCENT = "#1E88E5"
ACCENT_DARK = "#1565C0"
TEXT = "#0D2B45"
GREEN = "#2E7D32"
ORANGE = "#EF6C00"
RED = "#C62828"
FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI", 16, "bold")
MONO = ("Consolas", 10)

DEFAULT_MODEL = "gpt-4o-mini"
MAX_CODE_CHARS = 60000

SEVERITY_COLORS = {"Critical": "#B71C1C", "High": RED, "Medium": ORANGE, "Low": "#1976D2",
                   "Info": "#607D8B"}

CODE_EXTENSIONS = {
    ".py": "Python", ".java": "Java", ".js": "JavaScript", ".jsx": "JavaScript",
    ".ts": "TypeScript", ".tsx": "TypeScript", ".c": "C", ".h": "C", ".cpp": "C++",
    ".cc": "C++", ".hpp": "C++", ".cs": "C#", ".go": "Go", ".rb": "Ruby", ".php": "PHP",
    ".swift": "Swift", ".kt": "Kotlin", ".rs": "Rust", ".scala": "Scala", ".sql": "SQL",
    ".sh": "Shell", ".ps1": "PowerShell", ".r": "R", ".m": "Objective-C", ".dart": "Dart",
    ".html": "HTML", ".css": "CSS", ".vb": "VB.NET", ".pl": "Perl", ".lua": "Lua",
}
LANGUAGES = ["Auto Detect"] + sorted(set(CODE_EXTENSIONS.values()))

# (name, icon, focus given to the AI reviewer)
CHECKS = [
    ("Best Practices", "⭐",
     "Language idioms and conventions, proper use of standard library, avoiding anti-patterns, "
     "magic numbers, hard-coded values, global state, resource management (closing files/connections)."),
    ("Secure Coding", "🔒",
     "OWASP Top 10 and CWE issues: injection (SQL/command/code), XSS, hard-coded secrets/keys, "
     "insecure deserialization, weak crypto, path traversal, SSRF, missing input validation, "
     "unsafe eval/exec, insecure randomness, sensitive data exposure in logs."),
    ("Bugs & Logic Errors", "🐞",
     "Logic errors, off-by-one, null/None dereference, wrong conditions, unreachable code, "
     "race conditions, incorrect types, infinite loops, mutable default args, edge cases."),
    ("Performance", "⚡",
     "Algorithmic complexity, unnecessary loops, repeated computation, N+1 queries, inefficient "
     "data structures, memory leaks, blocking I/O, string concatenation in loops, caching opportunities."),
    ("Error Handling", "🛡",
     "Missing try/except, bare or overly broad catches, swallowed exceptions, missing cleanup "
     "(finally/with), unhelpful error messages, missing validation of external input/return values."),
    ("Readability & Style", "📖",
     "Naming quality, formatting, consistent style guide (PEP8, Google style, etc.), long lines, "
     "deep nesting, confusing expressions, dead/commented-out code."),
    ("Maintainability", "🔧",
     "Function/class length, cyclomatic complexity, code duplication (DRY), coupling, "
     "cohesion, modularity, configuration hard-coding, ease of future change."),
    ("Documentation", "📝",
     "Docstrings/header comments, parameter and return documentation, explanatory comments for "
     "non-obvious logic, outdated or misleading comments, README-worthy usage notes."),
    ("Testability", "🧪",
     "How easy the code is to unit test: dependency injection, side effects, hidden I/O, "
     "pure functions, existing tests; suggest concrete test cases that should be written."),
    ("Design & SOLID", "🏗",
     "SOLID principles, separation of concerns, appropriate design patterns, abstraction levels, "
     "scalability of the architecture, API/interface design."),
]

SYSTEM_PROMPT = """You are a Principal Software Engineer and expert code reviewer.
You review code across all programming languages with precision.
Only report real, specific issues found in the given code; do not invent problems.
Line numbers refer to the numbered code you receive.
Respond ONLY with valid JSON using exactly these keys:
{
  "score": integer 0-100 (100 = excellent for this check),
  "summary": string (2-3 sentences on this aspect of the code),
  "issues": [
    {"severity": "Critical|High|Medium|Low|Info",
     "line": string (e.g. "12" or "12-18" or "-"),
     "title": string,
     "description": string,
     "fix": string (concrete fix, may include a short code snippet)}
  ],
  "good_practices": [string]  (things done well for this check),
  "recommendations": [string]
}"""


def number_lines(code):
    return "\n".join(f"{i:4}| {line}" for i, line in enumerate(code.splitlines(), 1))


def run_check(client, model, language, code, check):
    name, _, focus = check
    user_msg = (
        f"REVIEW CHECK: {name}\nFOCUS: {focus}\n"
        f"LANGUAGE: {language}\n\nCODE:\n{number_lines(code)}"
    )
    resp = client.chat.completions.create(
        model=model,
        temperature=0.1,
        response_format={"type": "json_object"},
        messages=[{"role": "system", "content": SYSTEM_PROMPT},
                  {"role": "user", "content": user_msg}],
    )
    data = json.loads(resp.choices[0].message.content)
    data["score"] = max(0, min(100, int(float(data.get("score", 0)))))
    data["issues"] = data.get("issues") or []
    return data


def grade_for(score):
    for limit, grade in ((90, "A"), (80, "B"), (70, "C"), (60, "D")):
        if score >= limit:
            return grade
    return "F"


def color_for(score):
    return GREEN if score >= 80 else ORANGE if score >= 60 else RED


# ------------------------------------------------------------------ app ----
class CodeReviewApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("AI Code Review Studio - 10-Point Code Analysis")
        self.geometry("1200x800")
        self.minsize(1000, 680)
        self.configure(bg=BG)

        self.results = {}          # check name -> result dict
        self.language_used = ""
        self.reviewed_code = ""

        self._style()
        self._build_header()
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        self._build_input_tab()
        self._build_dashboard_tab()
        self._build_details_tab()
        self._build_improved_tab()

    # ------------------------------------------------------------ styling --
    def _style(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure(".", background=BG, foreground=TEXT, font=FONT)
        s.configure("TFrame", background=BG)
        s.configure("Panel.TFrame", background=PANEL)
        s.configure("TLabel", background=BG, foreground=TEXT)
        s.configure("Panel.TLabel", background=PANEL)
        s.configure("TLabelframe", background=PANEL, bordercolor="#BBDEFB")
        s.configure("TLabelframe.Label", background=PANEL, foreground=ACCENT_DARK, font=FONT_BOLD)
        s.configure("TCheckbutton", background=PANEL)
        s.configure("TNotebook", background=BG, borderwidth=0)
        s.configure("TNotebook.Tab", background="#D6EAFE", foreground=TEXT,
                    padding=(14, 7), font=FONT_BOLD)
        s.map("TNotebook.Tab", background=[("selected", ACCENT)],
              foreground=[("selected", "white")])
        s.configure("Accent.TButton", background=ACCENT, foreground="white",
                    font=FONT_BOLD, padding=(12, 6), borderwidth=0)
        s.map("Accent.TButton", background=[("active", ACCENT_DARK), ("disabled", "#90CAF9")])
        s.configure("TButton", background="#D6EAFE", foreground=TEXT, padding=(10, 5), borderwidth=0)
        s.map("TButton", background=[("active", "#BBDEFB")])
        s.configure("Treeview", background="white", fieldbackground="white", rowheight=30, font=FONT)
        s.configure("Treeview.Heading", background=ACCENT, foreground="white", font=FONT_BOLD)
        s.map("Treeview.Heading", background=[("active", ACCENT_DARK)])
        s.map("Treeview", background=[("selected", "#90CAF9")], foreground=[("selected", TEXT)])

    def _build_header(self):
        bar = tk.Frame(self, bg=ACCENT)
        bar.pack(fill="x", pady=(0, 10))
        tk.Label(bar, text="🧑‍💻  AI Code Review Studio", bg=ACCENT, fg="white",
                 font=FONT_TITLE).pack(side="left", padx=16, pady=10)
        tk.Label(bar, text="Browse or paste code • 10 expert checks • Scores & fixes",
                 bg=ACCENT, fg="#E3F2FD", font=FONT).pack(side="right", padx=16)

    def _text(self, parent, mono=False, **kw):
        return scrolledtext.ScrolledText(parent, wrap="none" if mono else "word",
                                         font=MONO if mono else FONT, bg="white", fg=TEXT,
                                         relief="flat", highlightthickness=1,
                                         highlightcolor=ACCENT, highlightbackground="#BBDEFB",
                                         padx=8, pady=6, undo=True, **kw)

    # --------------------------------------------------------- input tab --
    def _build_input_tab(self):
        tab = ttk.Frame(self.nb, padding=10)
        self.nb.add(tab, text="💻  Code Input")

        api = ttk.LabelFrame(tab, text="OpenAI Settings", padding=10)
        api.pack(fill="x")
        ttk.Label(api, text="API Key:", style="Panel.TLabel").grid(row=0, column=0, sticky="w")
        self.api_var = tk.StringVar()
        self.api_entry = ttk.Entry(api, textvariable=self.api_var, show="•", width=50)
        self.api_entry.grid(row=0, column=1, padx=6, sticky="we")
        self.show_key = tk.BooleanVar()
        ttk.Checkbutton(api, text="Show", variable=self.show_key,
                        command=lambda: self.api_entry.config(
                            show="" if self.show_key.get() else "•")).grid(row=0, column=2)
        ttk.Label(api, text="Model:", style="Panel.TLabel").grid(row=0, column=3, padx=(16, 4))
        self.model_var = tk.StringVar(value=DEFAULT_MODEL)
        ttk.Combobox(api, textvariable=self.model_var, width=14,
                     values=["gpt-4o-mini", "gpt-4o", "gpt-4.1-mini", "gpt-4.1"]
                     ).grid(row=0, column=4)
        ttk.Label(api, text="Language:", style="Panel.TLabel").grid(row=0, column=5, padx=(16, 4))
        self.lang_var = tk.StringVar(value="Auto Detect")
        ttk.Combobox(api, textvariable=self.lang_var, values=LANGUAGES, width=14,
                     state="readonly").grid(row=0, column=6)
        api.columnconfigure(1, weight=1)

        # Code box
        box = ttk.LabelFrame(tab, text="Source Code  (browse file(s) or paste below)", padding=10)
        box.pack(fill="both", expand=True, pady=10)
        btns = ttk.Frame(box, style="Panel.TFrame")
        btns.pack(fill="x")
        ttk.Button(btns, text="📂 Browse File(s)...", style="Accent.TButton",
                   command=self.browse_files).pack(side="left")
        ttk.Button(btns, text="📋 Paste", command=self.paste_code).pack(side="left", padx=6)
        ttk.Button(btns, text="Clear", command=self.clear_code).pack(side="left")
        self.info_lbl = ttk.Label(btns, text="0 lines", style="Panel.TLabel")
        self.info_lbl.pack(side="right")
        self.code_text = self._text(box, mono=True)
        self.code_text.pack(fill="both", expand=True, pady=(8, 0))
        self.code_text.bind("<<Modified>>", self._on_code_change)

        # Checks selection
        chk = ttk.LabelFrame(tab, text="Checks to Run", padding=8)
        chk.pack(fill="x")
        self.check_vars = {}
        for i, (name, icon, _) in enumerate(CHECKS):
            var = tk.BooleanVar(value=True)
            self.check_vars[name] = var
            ttk.Checkbutton(chk, text=f"{icon} {name}", variable=var).grid(
                row=i // 5, column=i % 5, sticky="w", padx=8, pady=2)
        for c in range(5):
            chk.columnconfigure(c, weight=1)
        sel = ttk.Frame(chk, style="Panel.TFrame")
        sel.grid(row=2, column=0, columnspan=5, sticky="w", pady=(4, 0))
        ttk.Button(sel, text="Select All", command=lambda: self._set_all(True)).pack(side="left", padx=8)
        ttk.Button(sel, text="Select None", command=lambda: self._set_all(False)).pack(side="left")

        run = ttk.Frame(tab)
        run.pack(fill="x", pady=(10, 0))
        self.run_btn = ttk.Button(run, text="🔍  Analyze Code", style="Accent.TButton",
                                  command=self.start_review)
        self.run_btn.pack(side="left")
        self.progress = ttk.Progressbar(run, mode="determinate", length=320)
        self.progress.pack(side="left", padx=12)
        self.status_lbl = ttk.Label(run, text="Ready")
        self.status_lbl.pack(side="left")

    def _set_all(self, value):
        for v in self.check_vars.values():
            v.set(value)

    def _on_code_change(self, _=None):
        if self.code_text.edit_modified():
            code = self.code_text.get("1.0", "end-1c")
            self.info_lbl.config(text=f"{len(code.splitlines())} lines • {len(code)} chars")
            self.code_text.edit_modified(False)

    def browse_files(self):
        exts = " ".join(f"*{e}" for e in CODE_EXTENSIONS)
        paths = filedialog.askopenfilenames(
            title="Select source code file(s)",
            filetypes=[("Source code", exts), ("All files", "*.*")])
        if not paths:
            return
        parts = []
        for p in paths:
            try:
                with open(p, encoding="utf-8", errors="replace") as f:
                    content = f.read()
            except OSError as e:
                messagebox.showerror("Error", f"Could not read {p}:\n{e}")
                continue
            parts.append(f"# ===== File: {os.path.basename(p)} =====\n{content}"
                         if len(paths) > 1 else content)
        self.code_text.delete("1.0", "end")
        self.code_text.insert("1.0", "\n\n".join(parts))
        ext = os.path.splitext(paths[0])[1].lower()
        if ext in CODE_EXTENSIONS:
            self.lang_var.set(CODE_EXTENSIONS[ext])

    def paste_code(self):
        try:
            self.code_text.insert("insert", self.clipboard_get())
        except tk.TclError:
            messagebox.showinfo("Paste", "Clipboard is empty.")

    def clear_code(self):
        self.code_text.delete("1.0", "end")
        self.lang_var.set("Auto Detect")

    # ----------------------------------------------------- dashboard tab --
    def _build_dashboard_tab(self):
        tab = ttk.Frame(self.nb, padding=10)
        self.nb.add(tab, text="📊  Dashboard")

        top = tk.Frame(tab, bg=PANEL, highlightthickness=1, highlightbackground="#BBDEFB")
        top.pack(fill="x")
        self.score_lbl = tk.Label(top, text="--", font=("Segoe UI", 40, "bold"), bg=PANEL, fg=ACCENT)
        self.score_lbl.pack(side="left", padx=(24, 6), pady=10)
        box = tk.Frame(top, bg=PANEL)
        box.pack(side="left", pady=10)
        self.grade_lbl = tk.Label(box, text="Overall Score", font=("Segoe UI", 14, "bold"),
                                  bg=PANEL, fg=TEXT)
        self.grade_lbl.pack(anchor="w")
        self.meta_lbl = tk.Label(box, text="Run an analysis to see results.", font=FONT,
                                 bg=PANEL, fg="#5B7A99")
        self.meta_lbl.pack(anchor="w")
        self.sev_frame = tk.Frame(top, bg=PANEL)
        self.sev_frame.pack(side="right", padx=20)

        cols = ("check", "score", "grade", "critical", "high", "medium", "low", "status")
        heads = ("Check", "Score", "Grade", "Critical", "High", "Medium", "Low", "Status")
        widths = (240, 80, 70, 80, 80, 80, 80, 170)
        frame = ttk.Frame(tab)
        frame.pack(fill="both", expand=True, pady=10)
        self.tree = ttk.Treeview(frame, columns=cols, show="headings")
        for c, h, w in zip(cols, heads, widths):
            self.tree.heading(c, text=h)
            self.tree.column(c, width=w, anchor="w" if c == "check" else "center")
        self.tree.tag_configure("good", foreground=GREEN)
        self.tree.tag_configure("warn", foreground=ORANGE)
        self.tree.tag_configure("bad", foreground=RED)
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<Double-1>", self._open_check)

        btns = ttk.Frame(tab)
        btns.pack(fill="x")
        ttk.Button(btns, text="📄 Export HTML Report", style="Accent.TButton",
                   command=self.export_html).pack(side="left")
        ttk.Button(btns, text="💾 Export JSON", command=self.export_json).pack(side="left", padx=6)
        ttk.Label(btns, text="Tip: double-click a check to see its detailed findings.",
                  foreground="#5B7A99").pack(side="right")

    # -------------------------------------------------------- details tab --
    def _build_details_tab(self):
        tab = ttk.Frame(self.nb, padding=10)
        self.nb.add(tab, text="🔎  Detailed Checks")
        self.detail_nb = ttk.Notebook(tab)
        self.detail_nb.pack(fill="both", expand=True)
        self.detail_texts = {}
        for name, icon, _ in CHECKS:
            f = ttk.Frame(self.detail_nb, padding=6)
            self.detail_nb.add(f, text=f"{icon} {name}")
            t = self._text(f)
            t.pack(fill="both", expand=True)
            t.tag_configure("h1", font=("Segoe UI", 15, "bold"), foreground=ACCENT_DARK)
            t.tag_configure("h2", font=("Segoe UI", 11, "bold"), foreground=ACCENT_DARK, spacing1=10)
            t.tag_configure("title", font=FONT_BOLD, spacing1=8)
            t.tag_configure("fix", font=MONO, background="#EEF6FF", lmargin1=24, lmargin2=24)
            t.tag_configure("body", lmargin1=24, lmargin2=24)
            t.tag_configure("good", foreground=GREEN)
            t.tag_configure("muted", foreground="#5B7A99")
            for sev, col in SEVERITY_COLORS.items():
                t.tag_configure(sev, foreground="white", background=col, font=FONT_BOLD)
            for col in (GREEN, ORANGE, RED):
                t.tag_configure(col, foreground=col, font=("Segoe UI", 13, "bold"))
            t.insert("end", "Run an analysis to see findings for this check.", "muted")
            t.config(state="disabled")
            self.detail_texts[name] = t

    # ------------------------------------------------------- improved tab --
    def _build_improved_tab(self):
        tab = ttk.Frame(self.nb, padding=10)
        self.nb.add(tab, text="✨  Improved Code")
        btns = ttk.Frame(tab)
        btns.pack(fill="x")
        self.improve_btn = ttk.Button(btns, text="✨ Generate Improved Code", style="Accent.TButton",
                                      command=self.start_improve)
        self.improve_btn.pack(side="left")
        ttk.Button(btns, text="📋 Copy", command=self.copy_improved).pack(side="left", padx=6)
        ttk.Button(btns, text="💾 Save As...", command=self.save_improved).pack(side="left")
        self.improve_status = ttk.Label(btns, text="Fixes all issues found by the review.")
        self.improve_status.pack(side="left", padx=12)
        self.improved_text = self._text(tab, mono=True)
        self.improved_text.pack(fill="both", expand=True, pady=(8, 0))

    # ------------------------------------------------------------ review --
    def _client(self):
        key = self.api_var.get().strip()
        if not key:
            messagebox.showwarning("Missing", "Please enter your OpenAI API key.")
            return None
        try:
            from openai import OpenAI
        except ImportError:
            messagebox.showerror("Missing", "openai not installed. Run: pip install openai")
            return None
        return OpenAI(api_key=key)

    def start_review(self):
        code = self.code_text.get("1.0", "end-1c")
        if not code.strip():
            return messagebox.showwarning("Missing", "Please browse or paste some code.")
        checks = [c for c in CHECKS if self.check_vars[c[0]].get()]
        if not checks:
            return messagebox.showwarning("Missing", "Select at least one check.")
        if len(code) > MAX_CODE_CHARS:
            if not messagebox.askyesno(
                    "Large code", f"Code is {len(code)} chars; only the first {MAX_CODE_CHARS} "
                                  "will be reviewed. Continue?"):
                return
            code = code[:MAX_CODE_CHARS]
        client = self._client()
        if not client:
            return
        lang = self.lang_var.get()
        lang = "Unknown - detect it from the code" if lang == "Auto Detect" else lang

        self.results = {}
        self.reviewed_code = code
        self.language_used = self.lang_var.get()
        self.run_btn.config(state="disabled")
        self.progress.config(maximum=len(checks), value=0)
        self.status_lbl.config(text=f"Running {len(checks)} checks in parallel...")
        threading.Thread(target=self._run_review, daemon=True,
                         args=(client, self.model_var.get().strip() or DEFAULT_MODEL,
                               lang, code, checks)).start()

    def _run_review(self, client, model, lang, code, checks):
        done = 0
        with ThreadPoolExecutor(max_workers=5) as pool:
            futures = {pool.submit(run_check, client, model, lang, code, c): c[0] for c in checks}
            for fut in as_completed(futures):
                name = futures[fut]
                try:
                    result = fut.result()
                except Exception as e:
                    result = {"score": 0, "summary": f"Check failed: {e}", "issues": [],
                              "error": True}
                    if "401" in str(e) or "api key" in str(e).lower():
                        self.after(0, messagebox.showerror, "OpenAI Error",
                                   f"Authentication failed:\n{e}")
                self.results[name] = result
                done += 1
                self.after(0, self._progress_step, done, len(checks), name)
        self.after(0, self._review_done)

    def _progress_step(self, done, total, name):
        self.progress.config(value=done)
        self.status_lbl.config(text=f"Completed {done}/{total}: {name}")

    def _review_done(self):
        self.run_btn.config(state="normal")
        ok = [r for r in self.results.values() if not r.get("error")]
        self.status_lbl.config(text=f"Done: {len(ok)}/{len(self.results)} checks succeeded")
        self.refresh_dashboard()
        self.refresh_details()
        self.nb.select(1)

    # ------------------------------------------------------------ render --
    def overall_score(self):
        scores = [r["score"] for r in self.results.values() if not r.get("error")]
        return round(sum(scores) / len(scores)) if scores else 0

    def severity_counts(self, issues):
        counts = {s: 0 for s in SEVERITY_COLORS}
        for i in issues:
            sev = str(i.get("severity", "Info")).capitalize()
            counts[sev if sev in counts else "Info"] += 1
        return counts

    def refresh_dashboard(self):
        overall = self.overall_score()
        self.score_lbl.config(text=f"{overall}", fg=color_for(overall))
        self.grade_lbl.config(text=f"Overall Score  •  Grade {grade_for(overall)}")
        code = self.reviewed_code
        self.meta_lbl.config(text=f"Language: {self.language_used}   |   "
                                  f"{len(code.splitlines())} lines   |   "
                                  f"{len(self.results)} checks   |   "
                                  f"{datetime.now():%d %b %Y %H:%M}")

        all_issues = [i for r in self.results.values() for i in r["issues"]]
        totals = self.severity_counts(all_issues)
        for w in self.sev_frame.winfo_children():
            w.destroy()
        for sev in ("Critical", "High", "Medium", "Low"):
            cell = tk.Frame(self.sev_frame, bg=SEVERITY_COLORS[sev], padx=12, pady=4)
            cell.pack(side="left", padx=4)
            tk.Label(cell, text=str(totals[sev]), font=("Segoe UI", 16, "bold"),
                     bg=SEVERITY_COLORS[sev], fg="white").pack()
            tk.Label(cell, text=sev, font=FONT, bg=SEVERITY_COLORS[sev], fg="white").pack()

        self.tree.delete(*self.tree.get_children())
        for name, icon, _ in CHECKS:
            if name not in self.results:
                continue
            r = self.results[name]
            c = self.severity_counts(r["issues"])
            if r.get("error"):
                status, tag, score, grade = "⚠ Failed", "bad", "-", "-"
            else:
                score, grade = r["score"], grade_for(r["score"])
                if score >= 80:
                    status, tag = "✅ Good", "good"
                elif score >= 60:
                    status, tag = "⚠ Needs Work", "warn"
                else:
                    status, tag = "❌ Poor", "bad"
            self.tree.insert("", "end", iid=name, tags=(tag,), values=(
                f"{icon}  {name}", score, grade, c["Critical"], c["High"], c["Medium"],
                c["Low"], status))

    def refresh_details(self):
        order = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}
        for name, icon, _ in CHECKS:
            t = self.detail_texts[name]
            t.config(state="normal")
            t.delete("1.0", "end")
            r = self.results.get(name)
            if r is None:
                t.insert("end", "This check was not selected.", "muted")
                t.config(state="disabled")
                continue
            t.insert("end", f"{icon}  {name}\n", "h1")
            if r.get("error"):
                t.insert("end", r["summary"], RED)
                t.config(state="disabled")
                continue
            t.insert("end", f"Score: {r['score']}/100   Grade: {grade_for(r['score'])}\n",
                     color_for(r["score"]))
            t.insert("end", "\nSummary\n", "h2")
            t.insert("end", f"{r.get('summary', '')}\n")

            issues = sorted(r["issues"], key=lambda i: order.get(
                str(i.get("severity", "Info")).capitalize(), 5))
            t.insert("end", f"\nFindings ({len(issues)})\n", "h2")
            if not issues:
                t.insert("end", "No issues found for this check. 🎉\n", "good")
            for n, i in enumerate(issues, 1):
                sev = str(i.get("severity", "Info")).capitalize()
                sev = sev if sev in SEVERITY_COLORS else "Info"
                t.insert("end", f"\n{n}. ", "title")
                t.insert("end", f" {sev} ", sev)
                t.insert("end", f"  {i.get('title', '')}", "title")
                t.insert("end", f"   (line {i.get('line', '-')})\n", "muted")
                t.insert("end", f"{i.get('description', '')}\n", "body")
                if i.get("fix"):
                    t.insert("end", "Fix:\n", ("body", "good"))
                    t.insert("end", f"{i['fix']}\n", "fix")

            if r.get("good_practices"):
                t.insert("end", "\nWhat's Done Well\n", "h2")
                for g in r["good_practices"]:
                    t.insert("end", f"  ✔ {g}\n", "good")
            if r.get("recommendations"):
                t.insert("end", "\nRecommendations\n", "h2")
                for rec in r["recommendations"]:
                    t.insert("end", f"  • {rec}\n")
            t.config(state="disabled")

    def _open_check(self, _=None):
        sel = self.tree.selection()
        if not sel:
            return
        names = [c[0] for c in CHECKS]
        self.nb.select(2)
        self.detail_nb.select(names.index(sel[0]))

    # ---------------------------------------------------------- improved --
    def start_improve(self):
        if not self.results:
            return messagebox.showinfo("Improve", "Run the analysis first.")
        client = self._client()
        if not client:
            return
        issues = []
        for name, r in self.results.items():
            for i in r["issues"]:
                issues.append(f"[{name}] {i.get('severity')} line {i.get('line')}: "
                              f"{i.get('title')} - {i.get('fix', '')}")
        self.improve_btn.config(state="disabled")
        self.improve_status.config(text="Generating improved code...")
        threading.Thread(target=self._run_improve, daemon=True,
                         args=(client, self.model_var.get().strip() or DEFAULT_MODEL,
                               "\n".join(issues))).start()

    def _run_improve(self, client, model, issues):
        try:
            resp = client.chat.completions.create(
                model=model, temperature=0.1,
                messages=[
                    {"role": "system", "content":
                        "You are a Principal Software Engineer. Rewrite the given code so it fixes "
                        "all listed review issues while keeping the same behavior and language. "
                        "Add concise docstrings/comments where helpful. Return ONLY the complete "
                        "code, with no markdown fences and no explanation."},
                    {"role": "user", "content":
                        f"LANGUAGE: {self.language_used}\n\nISSUES:\n{issues}\n\n"
                        f"CODE:\n{self.reviewed_code}"}])
            code = resp.choices[0].message.content.strip()
            if code.startswith("```"):
                code = code.split("\n", 1)[1].rsplit("```", 1)[0]
            self.after(0, self._improve_done, code, None)
        except Exception as e:
            self.after(0, self._improve_done, None, e)

    def _improve_done(self, code, error):
        self.improve_btn.config(state="normal")
        if error:
            self.improve_status.config(text="Failed.")
            return messagebox.showerror("Improve", f"Could not generate code:\n{error}")
        self.improved_text.delete("1.0", "end")
        self.improved_text.insert("1.0", code)
        self.improve_status.config(text="Improved code ready. Review it before using.")

    def copy_improved(self):
        code = self.improved_text.get("1.0", "end-1c")
        if code.strip():
            self.clipboard_clear()
            self.clipboard_append(code)
            self.improve_status.config(text="Copied to clipboard.")

    def save_improved(self):
        code = self.improved_text.get("1.0", "end-1c")
        if not code.strip():
            return messagebox.showinfo("Save", "Nothing to save yet.")
        ext = next((e for e, l in CODE_EXTENSIONS.items() if l == self.language_used), ".txt")
        path = filedialog.asksaveasfilename(defaultextension=ext, initialfile=f"improved_code{ext}")
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write(code)
            messagebox.showinfo("Save", f"Saved:\n{path}")

    # ------------------------------------------------------------ export --
    def export_json(self):
        if not self.results:
            return messagebox.showinfo("Export", "Run the analysis first.")
        path = filedialog.asksaveasfilename(defaultextension=".json",
                                            initialfile="code_review.json")
        if path:
            with open(path, "w", encoding="utf-8") as f:
                json.dump({"language": self.language_used, "overall_score": self.overall_score(),
                           "generated": datetime.now().isoformat(), "checks": self.results},
                          f, indent=2)
            messagebox.showinfo("Export", f"Saved:\n{path}")

    def export_html(self):
        if not self.results:
            return messagebox.showinfo("Export", "Run the analysis first.")
        path = filedialog.asksaveasfilename(defaultextension=".html",
                                            initialfile="code_review_report.html")
        if not path:
            return
        e = html.escape
        overall = self.overall_score()
        rows, sections = [], []
        for name, icon, _ in CHECKS:
            r = self.results.get(name)
            if not r:
                continue
            score = "-" if r.get("error") else r["score"]
            col = RED if r.get("error") else color_for(r["score"])
            rows.append(f"<tr><td>{icon} {e(name)}</td><td style='color:{col};font-weight:bold'>"
                        f"{score}</td><td>{len(r['issues'])}</td></tr>")
            items = "".join(
                f"<div class='issue'><span class='sev' style='background:"
                f"{SEVERITY_COLORS.get(str(i.get('severity', 'Info')).capitalize(), '#607D8B')}'>"
                f"{e(str(i.get('severity', '')))}</span> <b>{e(str(i.get('title', '')))}</b> "
                f"<small>(line {e(str(i.get('line', '-')))})</small>"
                f"<p>{e(str(i.get('description', '')))}</p>"
                f"<pre>{e(str(i.get('fix', '')))}</pre></div>" for i in r["issues"])
            recs = "".join(f"<li>{e(str(x))}</li>" for x in r.get("recommendations") or [])
            sections.append(f"<h2>{icon} {e(name)} — {score}</h2><p>{e(r.get('summary', ''))}</p>"
                            f"{items or '<p>No issues found.</p>'}"
                            f"{'<h4>Recommendations</h4><ul>' + recs + '</ul>' if recs else ''}")
        doc = f"""<!doctype html><html><head><meta charset="utf-8"><title>Code Review Report</title>
<style>body{{font-family:Segoe UI,Arial;background:{BG};color:{TEXT};margin:0;padding:24px}}
.card{{background:#fff;border-radius:10px;padding:20px;margin-bottom:16px;box-shadow:0 1px 4px #0002}}
h1{{color:{ACCENT_DARK}}} h2{{color:{ACCENT_DARK};border-bottom:2px solid #BBDEFB;padding-bottom:4px}}
table{{border-collapse:collapse;width:100%}} th{{background:{ACCENT};color:#fff}}
th,td{{padding:8px;border-bottom:1px solid #ddd;text-align:left}}
.issue{{border-left:4px solid {ACCENT};padding:6px 12px;margin:10px 0;background:{PANEL}}}
.sev{{color:#fff;padding:2px 8px;border-radius:4px;font-size:12px}}
pre{{background:#EEF6FF;padding:8px;white-space:pre-wrap}}</style></head><body>
<div class="card"><h1>Code Review Report</h1>
<p><b>Overall Score:</b> <span style="font-size:28px;color:{color_for(overall)}">{overall}</span>
 (Grade {grade_for(overall)}) &nbsp; | &nbsp; Language: {e(self.language_used)} &nbsp; | &nbsp;
 {datetime.now():%d %b %Y %H:%M}</p>
<table><tr><th>Check</th><th>Score</th><th>Issues</th></tr>{''.join(rows)}</table></div>
<div class="card">{''.join(sections)}</div></body></html>"""
        with open(path, "w", encoding="utf-8") as f:
            f.write(doc)
        messagebox.showinfo("Export", f"Report saved:\n{path}")


if __name__ == "__main__":
    CodeReviewApp().mainloop()
